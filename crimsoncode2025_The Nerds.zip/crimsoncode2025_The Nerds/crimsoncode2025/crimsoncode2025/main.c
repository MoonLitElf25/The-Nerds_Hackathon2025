/*
* 
* Team: Ryan Hymas, Ryan Heisler, Alex Petersen
* Program: D&D One-Shot, Choose your own adventure
* Theme "Art in Innovation"
* Description: In thise prgram your able to name and sleect a premade character class. YOu then carry on through the differernt stages of the campaign explaring different area and gathering information 
* to ultimently help you understand the lore of the campaign, it also include 2-3 different combat situatuins all determined by randimized number genration and hard coded states. That give a challege
* to the player. 
*/

#include "header.h"

int main(void) {
	srand((unsigned int)time(NULL));

	initplayer();

	int enemy_AC = randRange(1, 8); // enemy AC creation

	int enemy_Health = randRange(20, 50); // enemy Health assigment 

	int horde_enemy_AC = randRange(1, 5);

	int horde_enemy_Health = randRange(50, 200);

	//act 1
	int start = intro();
	int choice = 0;
	int go_ruins = 0;
	int iteration = 0;
	//tells if you find artifacts in the ruins or not
	int artifact_count = 0;
	//see if you know vecna is responsible or not, for act 3
	int vecna = 0;

	int rec = 0;
	int knowledge = 0;
	int mats = 0;
	int mats_mod = 0;
	int fight = 0;
	int result = 0;

	//if start = 2, king start + king access, else ya on ur own
	do {
		if (start == 2 && iteration == 0) {
			//king portion of story, with royal archives access
			if (king(md) == 1) {
				go_ruins = 1;
			}
		}
		else {
			do {
				printf("where to?\n1: research through libraries\n2: ask townsfolk\n");
				scanf("%d", &choice);
			} while (choice < 1 || choice > 2);
			go_ruins = town(choice, mod_hist);
			iteration++;
		}
	} while (go_ruins == 0);

	//ruins portion
	artifact_count = ruins(md);

	//back to town
	switch (artifact_count) {
	case 0: 
		printf("bro wtf? plot reasons: people are attacking tonight prepare for combat");
		break;
	case 1: 
		decoder();
		break;
	case 2:
		vecna = library(artifact_count);
		break;
	case 3: 
		vecna = library(artifact_count);
		break;
	}

	//act 2
	knowledge = research_enemies(mod_hist);
	mats_mod = knowledge + mod_hist;
	rec = recruits(mod_pro);
	mats = materials(mats_mod);

	fight = horde_combat(horde_enemy_AC, horde_enemy_Health, rec);


	result = combat(enemy_AC, enemy_Health);
	
	// Combat victory or defeat message
	if (result == 1)
	{
		printf("Victory! You live to fight another day.\n");
	}
	else
	{
		printf("Try again, adventurer.\n");
	}

	player_healing();

	// Horde combat victory or defeat message
	if (fight == 1)
	{
		printf("Victory! You live to fight another day.\n");
	}
	else
	{
		printf("Try again, adventurer.\n");
	}

	//act 3
	if (start == 2)
	{
		king_dialogue(artifact_count);
	}
	else
	{
		wizard_dialogue(artifact_count);
	}

	printf("You got PAID SON!!!\n");
	printf("You then leave with unanswered questions like 'How can we strengthen the city?','When will they attack next?', 'Is the wizard good?', and 'What is the sword?.Sadly though you'll never know...\n");

	return 0;
}