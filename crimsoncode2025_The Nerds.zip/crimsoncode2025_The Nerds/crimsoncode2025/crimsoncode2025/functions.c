#include "header.h"
int md = 3;
//dice functions
int roll_d20(int mod) {
	return rand() % 20 + 1 + mod;
}

int roll_d12(int mod) {
	return rand() % 12 + 1 + mod;
}

int roll_d10(int mod) {
	return rand() % 10 + 1 + mod;
}

int roll_d8(int mod) {
	return rand() % 8 + 1 + mod;
}

int roll_d6(int mod) {
	return rand() % 6 + 1 + mod;
}

int roll_d4(int mod) {
	return rand() % 4 + 1 + mod;
}

//starting locations + intro
int intro(void) {
	int start = rand() % 3;
	switch (start) {
	case 0: tavern_s();
		break;
	case 1: encampment_s();
		break;
	case 2: castle_s();
		break;
	}

	return start;
}

void tavern_s(void) {
	printf("tavern\n");
}

void encampment_s(void) {
	printf("encampment\n");
}

void castle_s(void) {
	printf("castle\n");
}

//ruins locations
int ruins(int mod) {
	//set found objects 0 - 3 depending on values called
	int found_objects = 0;
	if (ruins_main_chamber(mod)) {
		if (ruins_spiral_staircase(mod)) {
			found_objects++;
			printf("book");
		}
	}

	if (ruins_temple(mod)) {
		if (ruins_ladder(mod)) {
			found_objects++;
			printf("artifact");
		}
	}

	if (ruins_ladder(mod) && ruins_spiral_staircase(mod)) {
		found_objects++;
		printf("both");
	}
	printf("%d", found_objects);
	return found_objects;
}

//rolls to see if you found things
int ruins_spiral_staircase(int mod) {
	int DC = 11;
	return check(DC, mod);
}

int ruins_main_chamber(int mod) {
	printf("You enter into the main chamber of the ruins. You investigate the surrounding area, finding...\n");
	int DC = 8;
	return check(DC, mod);
}

int ruins_temple(int mod) {
	int DC = 6;
	return check(DC, mod);
}

int ruins_ladder(int mod) {
	int DC = 13;
	return check(DC, mod);
}

//checks if you fail or succeed a skill check by rolling a d20, adding the modifier, then comparing it to the DC
int check(int DC, int mod) {
	int check = roll_d20(mod);
	if (check >= DC) {
		return 1;
	}
	return 0;
}

//king path
int king(int mod) {
	int choice = 0;
	int ruins = 0;
	int DC = 5;
	do {
		printf("king tells you increased amount of monsters in the area\n");
		printf("1. ask to use royal archives\n2. leave to find info elsewhere\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 2);

	if (choice == 1) {
		if (check(DC, mod)) {
			printf("yea ok\n");
			ruins = royal_archives(mod);
		}
		else {
			printf("no, leave\n");
		}
	}
	return ruins;
}

//crazy person
int crazy_person(void) {
	int choice = 0;
	int info_found = 0;
	do {
		printf("theres a crazy thing outside the walls ive done seen it\n");
		printf("1. go on....\n2. ur crazy (leave and find info elsewhere)\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 2);

	if (choice == 1) {
		printf("theres these dang gang old buildin outside in that there forest where all the monsters are comin from\n");
		info_found = 1;
	}

	return info_found;
}

//research in libraries/archives
int royal_archives(int mod) {
	int DC = 5;
	int info_found = 0;

	if (check(DC, mod)) {
		printf("way more undead in recent times than before, also weird ruins on the outskirts of the town\n");
		info_found = 1;
	}
	else {
		printf("going to find another place to find info\n");
	}

	return info_found;
}

int librarian(int mod) {
	int choice = 0;
	int DC = 10;
	int info_found = 0;

	printf("you go to the library, where you meet the librarian");
	do {
		printf("hello little jit. would you like to use the library and peruse our knowledge?\n");
		printf("1. yes please\n2. hell nah im finna bounce\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 2);

	if (choice == 1) {
		if (check(DC, mod)) {
			info_found = 1;
		}
		else {
			printf("you found nothing gg, look somewhere else\n");
		}
	}

	return info_found;
}

int wizard(void) {
	int info_found = 0;
	int choice = 0;
	printf("you walk up to the wizard's tower, and knock on the door. he answers with haste:\n");

	do {
		printf("hello, what do you need young bucks?\n");
		printf("1. where are the monsters coming from\n2. idk why im here sorry (leave)\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 2);

	if (choice == 1) {
		printf("oh yeah theres a ruins outside of town maybe thats where they are coming from, but be careful going to it because of the monsters\n");
		info_found = 1;
	}

	return info_found;
}

//checks if you alert zombies. if combat = 0, go to combat. else, no combat
int roaming(int mod) {
	printf("you venture forth into the forest toward the ruins. you hear the moans and yells of the undead in the surrounding area.\n");
	printf("you have to be quiet going forward. roll a stealth check to see if you evade them\n");
	int DC = 8;
	int combat = 0;
	if (!check(DC, mod)) {
		combat = 1;
	}
	return combat;
}

void decoder(void) {
	printf("reading this through, tells that there will be a large horde of things attacking the town TONIGHT\n");
}

int library(int artifact) {
	int vecna = 0;
	if (artifact == 2) {
		vecna = librarian_dialogue(artifact);
	}
	else if (artifact == 3) {
		vecna = librarian_dialogue(artifact);
		decoder();
	}

	return vecna;
}

int librarian_dialogue(int artifact_count) {
	int vecna = 0;
	if (artifact_count == 2 || artifact_count == 3) {
		printf("wtf its vecna\n");
		vecna = 1;
	}
	else {
		printf("idk could be anybody bro\n");
	}
	printf("they are attacking tonight.\n");
	return vecna;
}

int town(int choice, int mod) {
	int go_ruins = 0;
	if (choice == 1) {
		go_ruins = librarian(mod);
	}
	else if (choice == 2) {
		printf("explore round city or go back to tavern?\n1. explore\n2. tavern");
		scanf("%d", &choice);
		if (choice == 1) {
			go_ruins = crazy_person();
		}
		else {
			go_ruins = tavern();
		}
	}
	return go_ruins;
}

int tavern(void) {
	int choice = 0;
	int go_ruins = 0;
	printf("lots of hubbub round here");
	printf("crazy old man in the corner murmuring to himself");
	do {
		printf("walk up to him or stay within your group?\n1: walk up\n2: leave him alone\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 2);
	if (choice == 1) {
		go_ruins = crazy_person();
	}
	else {
		go_ruins = tavern_people();
	}
	return go_ruins;
}

int tavern_people(void) {
	int go_ruins = 1;
	printf("you start eavesdropping on conversaions...\n");
	printf("\"lots of weird things have been happening\"\n");
	printf("\"yeah i was wandering round them woods and i found some old broken down ruins of some kind\"\n");
	return go_ruins;
}

void king_dialogue(int artifact) {
	if (artifact != 0) {
		printf("Weird lookin objects, you have there. You get a bonus!\n");
	}
}

void wizard_dialogue(int artifact) {
	if (artifact == 0 || artifact == 2)
	{
		printf("I don't know, it could be anybody doing this.\n");
	}
	if (artifact == 1 || artifact == 3)
	{
		printf("IT's VECNA!!\n");
	}
}

// Global variables for players states
char play_Name[MAX_NAME_LENGTH];
char play_Class[MAX_NAME_LENGTH];
int play_Health; // HP
int play_Str; // Streagth 
int play_Dex; // Dexarity 
int play_Con; // Constituiton 
int play_Int; // Intelligence 
int play_Wis; // Wisdom
int play_Cha; // Charisma 
int play_Ac; // Armor class
int mod_str; // Attack 
int mod_hist; // History 
int mod_inv; // Investigation 
int mod_pro; // Persuasion
int mod_ste; // Stealth
int heal_max; // Healing factor 

int randRange(int min, int max)
{
	return min + rand() % (max - min + 1);
}

void initplayer()
{
	printf("Enter your character's name: ");
	scanf("%49s", play_Name);
	getchar();

	// Choose a class
	printf("Choose your clas (1 for Fighter, 2 for Rouge, 3 for Wizard, 4 for Warlock, 5 for Bard, 6 for Barbarian, 7 for Sorcerer:  ");
	int choice = 0;
	scanf("%d", &choice);
	getchar();

	switch (choice)
	{
	case 1:
		play_Health = 44;
		play_Str = 20;
		play_Dex = 16;
		play_Con = 19;
		play_Int = 13;
		play_Wis = 15;
		play_Cha = 11;
		play_Ac = 18;
		mod_hist = 1;
		mod_str = 5;
		mod_inv = 1;
		mod_pro = 0;
		mod_ste = 3;
		heal_max = 44;
		snprintf(play_Class, MAX_NAME_LENGTH, "Fighter");
		break;

	case 2:
		play_Health = 35;
		play_Str = 13;
		play_Dex = 18;
		play_Con = 13;
		play_Int = 19;
		play_Wis = 15;
		play_Cha = 17;
		play_Ac = 15;
		mod_hist = 4;
		mod_str = 1;
		mod_inv = 4;
		mod_pro = 3;
		mod_ste = 4;
		heal_max = 35;
		snprintf(play_Class, MAX_NAME_LENGTH, "Rouge");
		break;

	case 3:
		play_Health = 28;
		play_Str = 12;
		play_Dex = 15;
		play_Con = 14;
		play_Int = 20;
		play_Wis = 19;
		play_Cha = 17;
		play_Ac = 12;
		mod_hist = 5;
		mod_str = 1;
		mod_inv = 5;
		mod_pro = 3;
		mod_ste = 2;
		heal_max = 28;
		snprintf(play_Class, MAX_NAME_LENGTH, "Wizard");
		break;

	case 4:
		play_Health = 35;
		play_Str = 13;
		play_Dex = 15;
		play_Con = 12;
		play_Int = 14;
		play_Wis = 19;
		play_Cha = 20;
		play_Ac = 14;
		mod_hist = 2;
		mod_str = 1;
		mod_inv = 2;
		mod_pro = 5;
		mod_ste = 2;
		heal_max = 35;
		snprintf(play_Class, MAX_NAME_LENGTH, "Warlock");
		break;

	case 5:
		play_Health = 43;
		play_Str = 13;
		play_Dex = 19;
		play_Con = 16;
		play_Int = 15;
		play_Wis = 12;
		play_Cha = 18;
		play_Ac = 17;
		mod_hist = 2;
		mod_str = 1;
		mod_inv = 2;
		mod_pro = 4;
		mod_ste = 4;
		heal_max = 43;
		snprintf(play_Class, MAX_NAME_LENGTH, "Bard");
		break;

	case 6:
		play_Health = 66;
		play_Str = 20;
		play_Dex = 16;
		play_Con = 19;
		play_Int = 12;
		play_Wis = 13;
		play_Cha = 10;
		play_Ac = 17;
		mod_hist = 1;
		mod_str = 5;
		mod_inv = 1;
		mod_pro = 0;
		mod_ste = 3;
		heal_max = 66;
		snprintf(play_Class, MAX_NAME_LENGTH, "Barbarian");
		break;

	case 7:
		play_Health = 47;
		play_Str = 12;
		play_Dex = 13;
		play_Con = 20;
		play_Int = 17;
		play_Wis = 15;
		play_Cha = 19;
		play_Ac = 15;
		mod_hist = 3;
		mod_str = 1;
		mod_inv = 3;
		mod_pro = 4;
		mod_ste = 1;
		heal_max = 47;
		snprintf(play_Class, MAX_NAME_LENGTH, "Sorcerer");
		break;

	default:
		printf("Inviald class selection, defaulting to Barbarian.\n");
		play_Health = 66;
		play_Str = 20;
		play_Dex = 16;
		play_Con = 19;
		play_Int = 12;
		play_Wis = 13;
		play_Cha = 10;
		play_Ac = 17;
		mod_hist = 1;
		mod_str = 5;
		mod_inv = 1;
		mod_pro = 0;
		mod_ste = 3;
		heal_max = 66;
		snprintf(play_Class, MAX_NAME_LENGTH, "Barbarian");
		break;
		printf("\nCharacter created: %s, the %s\n", play_Name, play_Class);
		printf("Health: %d, AC: %d\n", play_Health, play_Ac);
	}
}




int player_healing()
{
	// Check if the player needs healing
	if (play_Health < heal_max)
	{
		int healing_amount = heal_max / 2; // Heal by a fraction (or full heal if you want)

		// Apply healing
		play_Health += healing_amount;

		// Ensure that play_Health does not exceed heal_max
		if (play_Health > heal_max)
		{
			play_Health = heal_max; // Cap health at maximum
		}

		printf("You have been healed! Your current health is %d.\n", play_Health);
	}
	else
	{
		// Player is already at full health, no need for healing
		printf("You are at full health! No healing needed.\n");
	}

	return play_Health;
}




// Simulate combat
int combat(int enemy_AC, int enemy_Health)
{
	printf("\nA wild enemy appers! The enemy has %d HP and an AC of %d.\n", enemy_Health, enemy_AC);
	while (play_Health > 0 && enemy_Health > 0)
	{
		int attack_Roll = randRange(1, 20) + play_Str;
		printf("You attack! Roll: %d (attack: %d)\n", attack_Roll, play_Str);

		if (attack_Roll >= enemy_AC)
		{
			int damage = randRange(1, 8) + play_Str / 2;
			enemy_Health -= damage;
			printf("Hit! You dealt %d damage. Enemy HP: %d\n", damage, enemy_Health);
		}
		else
		{
			printf("Missed! Your attack did not hit.\n");
		}

		if (enemy_Health > 0)
		{
			int enemy_Attack_roll = randRange(1, 20) + 2; // enemy attack roll 
			if (enemy_Attack_roll >= play_Ac)
			{
				int enemy_Damage = randRange(1, 6) + 2; // enemy damage
				play_Health -= enemy_Damage;
				printf("The enemy attacks! You take %d damage. Your HP: %d\n", enemy_Damage, play_Health);
			}
			else
			{
				printf("The enemy misses!\n");
			}

		}
	}
	if (play_Health <= 0)
	{
		printf("You have been defeated! Game Over! \n");
		return 0;
	}
	printf("You have defeated the enemy!\n");
	player_healing(play_Health, heal_max);
	printf("Your helath is now: %d\n", play_Health);
	return 1;
}

int horde_combat(int horde_enemy_AC, int horde_enemy_Health, int recruits)
{
	// Initialize result to 0 (loss)
	int result = 0;

	printf("\nA horde of enemies appears! There are %d enemies all with an AC of %d.\n", horde_enemy_Health, horde_enemy_AC);

	while (play_Health > 0 && horde_enemy_Health > 0)
	{
		// Simulate player's attack
		int attack_Roll = randRange(1, 20) + play_Str + recruits;
		printf("You attack! Roll: %d (attack: %d)\n", attack_Roll, play_Str);

		if (attack_Roll >= horde_enemy_AC)
		{
			int damage = randRange(1, 8) + play_Str + recruits / 2;
			horde_enemy_Health -= damage;
			printf("Hit! You killed %d Enemies. Enemies Left: %d\n", damage, horde_enemy_Health);
		}
		else
		{
			printf("Missed! Your attack did not hit.\n");
		}

		// Enemy attacks
		if (horde_enemy_Health > 0)
		{
			int horde_enemy_Attack_roll = randRange(1, 20) + 2; // enemy attack roll 
			if (horde_enemy_Attack_roll >= play_Ac)
			{
				int horde_enemy_Damage = randRange(1, 6) + 2; // enemy damage
				play_Health -= horde_enemy_Damage;
				printf("The enemies attack! You take %d damage. Your HP: %d\n", horde_enemy_Damage, play_Health);
			}
			else
			{
				printf("The enemies miss!\n");
			}
		}
	}

	// Check if player is defeated
	if (play_Health <= 0)
	{
		printf("You have been defeated! Game Over! \n");
		return 0; // Defeat
	}

	// If the horde is defeated, set result to 1 for victory
	printf("You have defeated the horde!\n");
	player_healing(play_Health, heal_max);
	printf("Your health is now: %d\n", play_Health);
	result = 1; // Victory
	return result;
}

// The talking points for the quests/ lore
int research_enemies(int mod)
{
	printf("As you start to look for information about the enmeies that are approching you stubble across a paculaier book.\nAs you read you learn a Small Horde is 50 enemies, a Medium Horde is 100 enemies, and a Large Horde is 200 enemies\n");
	printf("At the end of the book you notice that there appears to be a acient langue. Do you: 1. attempt to read it or 2. put the book back?\n");

	int choice = 0;
	int roll = roll_d20(mod);
	scanf("%d", &choice);
	getchar();
	int knowledge = 0;

	switch (choice)
	{
	case 1:
		if (roll >= 14)
		{
			printf("The script starts to meld in legable words, a waring of the spell boss.\nThis creature spawns with a medium horde that are enchatted with a +3 damage bonus.\n");
			knowledge++;
		}
		else
		{
			printf("The words seem to bold into a black figure, but nothing is really readable due to it's old age\n");
		}
		break;

	case 2:
		printf("You place the book on it's shelf and start walking. But you can't shake the feeling that your missing something\n");
		break;

	default:
		printf("Invaild input, defaulting to choice one");
		if (roll >= 17)
		{
			printf("The script starts to meld in legable words, a waring of the spell boss.\nThis creature spawns with a medium horde that are enchatted with a +1 damage bonus to everything.\n");
			knowledge++;
		}
		else
		{
			printf("The words seem to bold into a black figure, but nothing is really readable due to it's old age\n");
		}
		break;
	}
	return knowledge;
}

//returns a multiplier for combat
int recruits(int mod) {
	printf("You go now to speak with the town to hopefully encourage them to join you in the upcoming battle.\n");
	int roll = roll_d20(mod);
	int recruits = 0;

	if (recruits == 1)
	{
		recruits = 0;
	}
	if (recruits >= 2 && recruits <= 5)
	{
		recruits = 1;
	}
	if (recruits >= 6 && recruits <= 12)
	{
		recruits = 2;
	}
	if (recruits >= 13 && recruits <= 19)
	{
		recruits = 5;
	}
	if (recruits == 20)
	{
		recruits = 10;
	}

	if (roll >= 2)
	{
		printf("You tell the people who you recruited to go wait by the front gate while you go gather materials.\n");
	}
	else
	{
		printf("No one was swayed enough to join your cause, and you are on your own. you now go in search of supplies.\n");
	}
	return recruits;
}

int materials(int mod) {
	printf("You are now searching through the entire town for supplies, let's see if you find anything.\n");
	int mats = 0;
	int roll = roll_d20(mod);
	int s = 0, m = 0, l = 0, o = 0;
	if (roll = 1)
	{
		mats = 0;
	}
	if (roll >= 2 && roll <= 5)
	{
		mats = 1;
	}
	if (roll >= 6 && roll <= 15)
	{
		mats = 2;
	}
	if (roll >= 16 && roll <= 19)
	{
		mats = 3;
	}
	if (roll == 20)
	{
		mats = 4;
	}
	if (roll >= 2)
	{
		printf("You were able to find some supplies for your jounrney! You are now ready to prepare for the horde.\n");
	}
	else
	{
		printf("You weren't able to find anything of use, but you still must stay dillegent and prepare for the horde.\n");
	}
	return mats;
}