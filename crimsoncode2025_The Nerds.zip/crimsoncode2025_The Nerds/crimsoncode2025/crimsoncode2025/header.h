#ifndef HEADER_H
#define HEADER_H

#define _CRT_SECURE_NO_WARNINGS
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define MAX_NAME_LENGTH 50
extern int md;

// Global player variables 
extern char play_Name[MAX_NAME_LENGTH];
extern	char play_Class[MAX_NAME_LENGTH];
extern	int play_Health; // HP
extern	int play_Str; // Streagth 
extern	int play_Dex; // Dexarity 
extern	int play_Con; // Constituiton 
extern	int play_Int; // Intelligence 
extern	int play_Wis; // Wisdom
extern	int play_Cha; // Charisma 
extern	int play_AC; // armor class
extern	int mod_str; // Attak
extern	int mod_hist; // History 
extern  int mod_inv; // Investigation 
extern  int mod_pro; // Persuasion
extern  int mod_ste; // Stealth
extern int heal_fact; // Healing factor 

// creating the player and NPCS
void initplayer();

// Dice rolls
int randRange(int min, int max);

// The combat mechanic
int combat(int enemyAC, int enemyHealth);

// Starting the game 
//void startAdventure();

// healling
int player_healing();

//rolls dice, passes in modifier to add to dice roll
//if no modifier input 0
int roll_d20(int mod);
int roll_d12(int mod);
int roll_d10(int mod);
int roll_d8(int mod);
int roll_d6(int mod);
int roll_d4(int mod);

//functions for starting locations
void tavern_s(void);
void encampment_s(void);
void castle_s(void);

//functions for places in city
int tavern(void);
int library(int artifact);
int roaming(int mod);

//returns an int, 0 if not found anything, 1 if found only book, 2 if found artifact, 3 if found both
int ruins(int mod);

//returns 0 if spiral staircase not found, 1 if found 
int ruins_main_chamber(int mod);

//returns 0 if artifact not found, 1 if found
int ruins_spiral_staircase(int mod);

//returns 0 if ladder not found, 1 if ladder found
int ruins_temple(int mod);

//returns an int where 0 = book not picked up, 1 = book picked up
int ruins_ladder(int mod);

//functions for npcs
int crazy_person(void);
int wizard(void);

//asks if you can use royal archives, if yea then you go to find info, if not then set choice to 2. returns choice.
//if choice = 2, then need to search things elsewhere. if not, then can go to ruins.
int king(int mod);


int librarian(int mod);
void decoder(void);
int royal_archives(int mod);

//functions for story, prints out dialogue

//intro passes a random starting int, int chooses where the story starts
int intro(void);
void wizard_dialogue(int artifact);
void king_dialogue(int artifact);
//void crazy_person_dialogue(int choice);
int librarian_dialogue(int artifact_count);
//void royal_archives_dialogue(int choice);

int check(int DC, int mod);

int town(int choice, int mod);
int tavern_people(void);

int research_enemies(int mod);

#endif